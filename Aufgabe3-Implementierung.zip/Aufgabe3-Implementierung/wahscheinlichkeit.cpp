#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <queue>
#include <chrono>
#include <random>
#include <tuple>
#include <iomanip>
#include <algorithm>

using namespace std;

const long long INF = 1e15;

// Zustands-Definition für die Top-Down DP: {aktueller_knoten, schritt_k, bitmaske_verfuegbare_werke, restzeit}
using State = tuple<int, int, int, long long>;

void solve() {
    long long L; // Zeitfrist
    cin >> L;
    int m; // Anzahl Arbeitsschritte
    cin >> m;

    vector<int> counts(m);
    for(int i = 0; i < m; ++i) {
        cin >> counts[i];
    }

    int w; // Anzahl aller Werke
    cin >> w;

    map<string, int> name_to_id;
    vector<string> node_names;

    auto get_id = [&](const string &s) {
        if(name_to_id.find(s) == name_to_id.end()) {
            name_to_id[s] = node_names.size();
            node_names.push_back(s);
        }
        return name_to_id[s];
    };

    int S_id = get_id("S");
    int T_id = get_id("T");

    vector<vector<int>> works(m + 1);
    for(int i = 0; i < w; ++i) {
        string wi;
        int step;
        cin >> wi >> step;
        int id = get_id(wi);
        works[step].push_back(id);
    }

    int edges_cnt;
    cin >> edges_cnt;

    struct EdgeInput {
        string u, v;
        long long t;
    };
    vector<EdgeInput> edges(edges_cnt);

    for(int i = 0; i < edges_cnt; ++i) {
        cin >> edges[i].u >> edges[i].v >> edges[i].t;
        get_id(edges[i].u);
        get_id(edges[i].v);
    }

    int N = node_names.size();

    // Streikwahrscheinlichkeiten generieren
    vector<double> strike_prob(N, 0.0);
    mt19937 rng(42); // Fester Seed für Reproduzierbarkeit
    uniform_real_distribution<double> dist_prob(0.05, 0.30);

    for (int k = 1; k <= m; ++k) {
        for (int u : works[k]) {
            strike_prob[u] = dist_prob(rng);
        }
    }

    struct Edge {
        int to;
        long long weight;
    };
    vector<vector<Edge>> adj(N);

    for(int i = 0; i < edges_cnt; ++i) {
        int u = get_id(edges[i].u);
        int v = get_id(edges[i].v);
        long long weight = edges[i].t;
        adj[u].push_back({v, weight});
        adj[v].push_back({u, weight});
    }

    // 1. Dijkstra für alle Paare (Bleibt erhalten: O(1) Distanz-Abfragen)
    vector<vector<long long>> dist_to(N, vector<long long>(N, INF));
    for(int dst = 0; dst < N; ++dst) {
        dist_to[dst][dst] = 0;
        priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<>> pq;
        pq.push({0, dst});

        while(!pq.empty()) {
            auto [d, u] = pq.top();
            pq.pop();
            if (d > dist_to[dst][u]) continue;

            for(auto &edge : adj[u]) {
                int v = edge.to;
                long long weight = edge.weight;
                if(dist_to[dst][u] + weight < dist_to[dst][v]) {
                    dist_to[dst][v] = dist_to[dst][u] + weight;
                    pq.push({dist_to[dst][v], v});
                }
            }
        }
    }

    auto dist_uv = [&](int u, int v) { return dist_to[v][u]; };

    // Top-Down DP mit Memoization
    map<State, double> memo; // Speichert maximale Erfolgswahrscheinlichkeit
    map<State, int> best_action; // Speichert bestes Werk für einen Zustand

    // Rekursive Funktion zur Berechnung der Wahrscheinlichkeiten
    auto get_prob = [&](auto& self, int x, int k, int mask, long long t) -> double {
        if (t < 0) return 0.0; // Zeit abgelaufen

        // Basisfall alle Arbeitsschritte erledigt -> geht es nochh bis zum Ziel?
        if (k == m + 1) {
            return (t >= dist_uv(x, T_id)) ? 1.0 : 0.0;
        }

        // keine Alternativen mehr für diesen Schritt übrig -> Mission gescheitert
        if (mask == 0) return 0.0;

        State state = {x, k, mask, t};
        if (memo.count(state)) return memo[state];

        double max_p = -1.0;
        int best_u = -1;

        // über alle noch verfügbaren Werke im aktuellen Schritt iterieren
        for (int i = 0; i < works[k].size(); ++i) {
            // Ist das i-te Werk noch im Bitmask-Set?
            if (mask & (1 << i)) {
                int u = works[k][i];
                long long d = dist_uv(x, u);

                if (t >= d && d != INF) {
                    double p_u = strike_prob[u]; // wahrscheinlichkeit dass u streikt

                    // Bitmaske für nächsten Schritt -> Alle Werke wieder verfügbar
                    int next_mask = (k + 1 <= m) ? ((1 << works[k+1].size()) - 1) : 0;

                    // Rekursiver MDP-Übergang (Erfolgswahrscheinlichkeit für diese Entscheidung)
                    double prob_success = (1.0 - p_u) * self(self, u, k + 1, next_mask, t - d)  +   p_u * self(self, u, k, mask ^ (1 << i), t - d);// Normalfall + Streikfall

                    // Maximieren und Tie-Breaking
                    if (prob_success > max_p || (prob_success == max_p && best_u != -1 && node_names[u] < node_names[best_u])) {
                        max_p = prob_success;
                        best_u = u;
                    }
                }
            }
        }

        if (max_p < 0.0) max_p = 0.0; // Sackgasse

        best_action[state] = best_u;
        return memo[state] = max_p;
    };

    // aufruf ab Start S, Schritt 1, volle Bitmaske für Schritt 1, volle Zeit L
    int initial_mask = (1 << works[1].size()) - 1;
    double final_prob = get_prob(get_prob, S_id, 1, initial_mask, L);

    if (final_prob == 0.0) {
        cout << "UNMOEGLICH\n(Frist L kann selbst mit optimaler Wahl unter keinen Umstaenden garantiert eingehalten werden)\n\n";
        return;
    }

    cout << "MOEGLICH\n";
    cout << "Maximale Erfolgswahrscheinlichkeit (Frist L=" << L << "): "
         << fixed << setprecision(2) << (final_prob * 100.0) << "%\n\n";

    // Rekonstruktion der Policy
    cout << "--- ENTSCHEIDUNGS-POLICY ---\n";

    int curr_x = S_id;
    long long curr_t = L;
    int curr_mask = initial_mask;

    cout << "Hauptroute (Keine Streiks): S";

    // verfolgung des Pfads, bei dem alle Werke offen sind
    for (int k = 1; k <= m; ++k) {
        State s = {curr_x, k, curr_mask, curr_t};
        if(best_action.find(s) == best_action.end() || best_action[s] == -1) break;

        int chosen_u = best_action[s];
        cout << " -> [" << node_names[chosen_u] << " (" << fixed << setprecision(1) << strike_prob[chosen_u]*100 << "% Streikrisiko)]";

        curr_t -= dist_uv(curr_x, chosen_u);
        curr_x = chosen_u;
        curr_mask = (k + 1 <= m) ? ((1 << works[k+1].size()) - 1) : 0;
    }
    cout << " -> T\n\n";

    cout << "Fallbacks (Wenn ein Werk der Hauptroute streikt):\n";
    curr_x = S_id;
    curr_t = L;
    curr_mask = initial_mask;

    for (int k = 1; k <= m; ++k) {
        State s = {curr_x, k, curr_mask, curr_t};
        if(best_action.find(s) == best_action.end() || best_action[s] == -1) break;

        int chosen_u = best_action[s];

        // Was wäre, wenn chosen_u streikt?
        int fallback_mask = curr_mask ^ (1 << (find(works[k].begin(), works[k].end(), chosen_u) - works[k].begin()));
        long long t_after_drive = curr_t - dist_uv(curr_x, chosen_u);

        State fallback_state = {chosen_u, k, fallback_mask, t_after_drive};

        if (best_action.find(fallback_state) != best_action.end() && best_action[fallback_state] != -1) {
            int alt_u = best_action[fallback_state];
            cout << "Schritt " << k << ": Falls [" << node_names[chosen_u] << "] streikt -> Weiche aus auf [" << node_names[alt_u] << "]\n";
        } else {
            cout << "Schritt " << k << ": Falls [" << node_names[chosen_u] << "] streikt -> Mission gescheitert (Kein rechtzeitiges Ausweichwerk)\n";
        }

        // weiter machen auf HauptRoute
        curr_t = t_after_drive;
        curr_x = chosen_u;
        curr_mask = (k + 1 <= m) ? ((1 << works[k+1].size()) - 1) : 0;
    }
    cout << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    string fileN = "00";
    cerr << "Welches Beispiel? ";
    cin >> fileN;

    string in_dir = "inputs/" + fileN + ".txt";
    string out_dir = "outputs/" + fileN + "_stochastisch_out.txt";

    freopen(in_dir.c_str(), "r", stdin);

    freopen(out_dir.c_str(), "w", stdout);

    auto t0 = chrono::high_resolution_clock::now();
    solve();
    auto t1 = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = t1 - t0;

    cerr << "Laufzeit: " << elapsed.count() << "s\n";

    return 0;
}
