#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <chrono>

using namespace std;

const long long INF = 1e15;

void solve() {
    long long L; // Zeitfrist
    cin >> L;
    int m; // Anzahl Arbeitsschritte
    cin >> m;

    // Anzahl der Werke pro Schritt
    vector<int> counts(m);
    for(int i = 0; i < m; ++i) {
        cin >> counts[i];
    }

    int w; // Anzahl aller Werke
    cin >> w;

    // Werke zwischenspeichern
    vector<pair<string, int>> temp_works(w);
    int max_node_id = 0;
    for(int i = 0; i < w; ++i) {
        cin >> temp_works[i].first >> temp_works[i].second;
        if(temp_works[i].first != "S" && temp_works[i].first != "T") {
            max_node_id = max(max_node_id, stoi(temp_works[i].first));
        }
    }

    int edges_cnt; // Anzahl der Straßen
    cin >> edges_cnt;

    // Straßen zwischenspeichern und maximale ID updaten
    struct EdgeInput {
        string u, v;
        long long t;
    };
    vector<EdgeInput> temp_edges(edges_cnt);
    for(int i = 0; i < edges_cnt; ++i) {
        cin >> temp_edges[i].u >> temp_edges[i].v >> temp_edges[i].t;
        if(temp_edges[i].u != "S" && temp_edges[i].u != "T") {
            max_node_id = max(max_node_id, stoi(temp_edges[i].u));
        }
        if(temp_edges[i].v != "S" && temp_edges[i].v != "T") {
            max_node_id = max(max_node_id, stoi(temp_edges[i].v));
        }
    }

    int n = max_node_id + 2;
    vector<string> node_names(n, "");
    node_names[0] = "S";
    node_names[n - 1] = "T";
    for(int i = 1; i <= max_node_id; ++i) {
        node_names[i] = to_string(i);
    }

    auto get_id = [&](const string &s) -> int {
        if (s == "S") return 0;
        if (s == "T") return n - 1;
        return stoi(s);
    };

    int S_id = get_id("S"); // Start
    int T_id = get_id("T"); // Ziel

    // Welches Werk gehört zu welchem Schritt?
    vector<vector<int>> works(m + 1);
    for(int i = 0; i < w; ++i) {
        int id = get_id(temp_works[i].first);
        works[temp_works[i].second].push_back(id);
    }

    int N = node_names.size();
    struct Edge {
        int to;
        long long weight;
    };
    vector<vector<Edge>> adj(N);

    // Ungerichteten Graphen aus den zwischengespeicherten Kanten aufbauen
    for(int i = 0; i < edges_cnt; ++i) {
        int u = get_id(temp_edges[i].u);
        int v = get_id(temp_edges[i].v);
        long long weight = temp_edges[i].t;
        adj[u].push_back({v, weight});
        adj[v].push_back({u, weight});
    }

    // 1. Dijkstra für alle Paare (Distanzen berechnen)
    vector<vector<long long>> dist_to(N, vector<long long>(N, INF));
    for(int dst = 0; dst < N; ++dst) {
        dist_to[dst][dst] = 0;
        priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<>> pq;
        pq.push({0, dst});

        while(!pq.empty()) {
            auto [d, u] = pq.top();
            pq.pop();

            if (d > dist_to[dst][u]) continue;

            for(auto &edge : adj[u]) {
                int v = edge.to;
                long long weight = edge.weight;
                if(dist_to[dst][u] + weight < dist_to[dst][v]) {
                    dist_to[dst][v] = dist_to[dst][u] + weight;
                    pq.push({dist_to[dst][v], v});
                }
            }
        }
    }

    auto dist_uv = [&](int u, int v) {
        return dist_to[v][u];
    };

    vector<vector<int>> next_node(N, vector<int>(N, -1));
    for(int u = 0; u < N; ++u) {
        for(int dst = 0; dst < N; ++dst) {
            if(u == dst || dist_to[dst][u] == INF) continue;
            for(auto &edge : adj[u]) {
                int v = edge.to;
                long long weight = edge.weight;
                if(dist_to[dst][v] != INF && weight + dist_to[dst][v] == dist_to[dst][u]) {
                    // Numerisches Tie-Breaking
                    if(next_node[u][dst] == -1 || v < next_node[u][dst]) {
                        next_node[u][dst] = v;
                    }
                }
            }
        }
    }

    // 2. DP rückwärts
    vector<vector<long long>> MinDist(N, vector<long long>(m + 1, INF));
    vector<vector<int>> NextNormal(N, vector<int>(m + 1, -1));

    for(int u : works[m]) {
        MinDist[u][m] = dist_uv(u, T_id);
    }

    for(int k = m - 1; k >= 1; --k) {
        for(int u : works[k]) {
            for(int v : works[k + 1]) {
                if(dist_uv(u, v) == INF || MinDist[v][k+1] == INF) continue;
                long long cand = dist_uv(u, v) + MinDist[v][k+1];

                if(cand < MinDist[u][k]) {
                    MinDist[u][k] = cand;
                    NextNormal[u][k] = v;
                } else if(cand == MinDist[u][k]) {
                    // Numerisches Tie-Breaking
                    if(NextNormal[u][k] == -1 || v < NextNormal[u][k]) {
                        NextNormal[u][k] = v;
                    }
                }
            }
        }
    }

    // 3. DP Streikkosten
    vector<vector<long long>> BestAltDist(N, vector<long long>(m + 1, INF));
    vector<vector<int>> NextAlt(N, vector<int>(m + 1, -1));

    for(int k = 1; k <= m; ++k) {
        for(int u : works[k]) {
            for(int v : works[k]) {
                if(u == v) continue;
                if(dist_uv(u, v) == INF || MinDist[v][k] == INF) continue;

                long long cand = dist_uv(u, v) + MinDist[v][k];
                if(cand < BestAltDist[u][k]) {
                    BestAltDist[u][k] = cand;
                    NextAlt[u][k] = v;
                } else if(cand == BestAltDist[u][k]) {
                    // Numerisches Tie-Breaking
                    if(NextAlt[u][k] == -1 || v < NextAlt[u][k]) {
                        NextAlt[u][k] = v;
                    }
                }
            }
        }
    }

    // 4. DP vorwärts
    vector<vector<long long>> MinArrival(N, vector<long long>(m + 1, INF));
    vector<vector<int>> PrevMain(N, vector<int>(m+1, -1));

    for(int u : works[1]) {
        if(dist_uv(S_id, u) == INF) continue;
        long long t = dist_uv(S_id, u);

        if(t + BestAltDist[u][1] <= L && t + MinDist[u][1] <= L) {
            MinArrival[u][1] = t;
        }
    }

    for(int k = 2; k <= m; ++k) {
        for(int u : works[k]) {
            for(int v: works[k-1]) {
                if(MinArrival[v][k-1] == INF || dist_uv(v, u) == INF) continue;

                long long t = MinArrival[v][k-1] + dist_uv(v, u);

                if(t + BestAltDist[u][k] <= L && t + MinDist[u][k] <= L) {
                    if(t < MinArrival[u][k]) {
                        MinArrival[u][k] = t;
                        PrevMain[u][k] = v;
                    } else if(t == MinArrival[u][k]) {
                        // Numerisches Tie-Breaking
                        if(PrevMain[u][k] == -1 || v < PrevMain[u][k]) {
                            PrevMain[u][k] = v;
                        }
                    }
                }
            }
        }
    }

    // 5. Zielprüfung und Rekonstruktion der Hauptroute
    long long min_total = INF;
    int best_w_m = -1;

    for(int u : works[m]) {
        if(MinArrival[u][m] == INF || dist_uv(u, T_id) == INF) continue;

        long long t = MinArrival[u][m] + dist_uv(u, T_id);
        if(t <= L) {
            if(t < min_total) {
                min_total = t;
                best_w_m = u;
            } else if(t == min_total) {
                // Numerisches Tie-Breaking
                if(best_w_m == -1 || u < best_w_m) {
                    best_w_m = u;
                }
            }
        }
    }

    if(best_w_m == -1) {
        cout << "UNMOEGLICH\n";
        return;
    }

    cout << "MOEGLICH\n";

    vector<int> W(m+1);
    W[m] = best_w_m;
    for(int k = m; k >= 2; --k) {
        W[k-1] = PrevMain[W[k]][k];
    }

    vector<long long> arr(m+1);
    arr[1] = dist_uv(S_id, W[1]);
    for(int k = 2; k <= m; ++k) {
        arr[k] = arr[k-1] + dist_uv(W[k-1], W[k]);
    }

    long long max_possible = min_total;
    for(int k = 1; k <= m; ++k) {
        long long alt = arr[k] + BestAltDist[W[k]][k];
        if(alt > max_possible) {
            max_possible = alt;
        }
    }

    cout << max_possible << "\n\n";

    auto print_path = [&](int u, int v, int step_for_v) {
        int curr = u;
        while (curr != v) {
            curr = next_node[curr][v];
            if (curr == v) {
                if (step_for_v != -1) {
                    cout << " [" << node_names[v] << " " << step_for_v << "]";
                } else {
                    cout << " " << node_names[v];
                }
            } else {
                cout << " " << node_names[curr];
            }
        }
    };

    cout << min_total << "\n";
    cout << "S";
    int curr = S_id;
    for (int k = 1; k <= m; ++k) {
        print_path(curr, W[k], k);
        curr = W[k];
    }
    print_path(curr, T_id, -1);
    cout << "\n";

    for (int k = 1; k <= m; ++k) {
        long long alt_duration = arr[k] + BestAltDist[W[k]][k];
        cout << alt_duration << "\n";

        cout << node_names[W[k]];
        curr = W[k];

        int v = NextAlt[W[k]][k];
        print_path(curr, v, k);
        curr = v;

        for (int j = k + 1; j <= m; ++j) {
            int nxt = NextNormal[curr][j - 1];
            print_path(curr, nxt, j);
            curr = nxt;
        }

        print_path(curr, T_id, -1);
        cout << "\n";
    }

    cout << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    string fileN = "00";
    cerr << "Welches Beispiel? ";
    cin >> fileN;

    string in_dir = "inputs/" + fileN + ".txt";
    string out_dir = "outputs/" + fileN + "_out.txt";

    freopen(in_dir.c_str(), "r", stdin);

    freopen(out_dir.c_str(), "w", stdout);

    auto t0 = chrono::high_resolution_clock::now();
    solve();
    auto t1 = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = t1 - t0;

    cerr << elapsed.count() << "s\n";

    return 0;
}
