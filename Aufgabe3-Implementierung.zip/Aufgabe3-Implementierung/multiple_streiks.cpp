#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <chrono>
#include <map>
#include <tuple>

using namespace std;

const long long INF = 1e15;

void solve(int max_strikes) {
    long long L; // Zeitfrist
    cin >> L;
    int m; // Anzahl Arbeitsschritte
    cin >> m;

    // Anzahl der Werke pro Schritt
    vector<int> counts(m);
    for(int i = 0; i < m; ++i) {
        cin >> counts[i];
    }

    int w; // Anzahl aller Werke
    cin >> w;

    // Werke zwischenspeichern
    vector<pair<string, int>> temp_works(w);
    int max_node_id = 0;
    for(int i = 0; i < w; ++i) {
        cin >> temp_works[i].first >> temp_works[i].second;
        if(temp_works[i].first != "S" && temp_works[i].first != "T") {
            max_node_id = max(max_node_id, stoi(temp_works[i].first));
        }
    }

    int edges_cnt; // Anzahl der Straßen
    cin >> edges_cnt;

    // Straßen zwischenspeichern und maximale ID updaten
    struct EdgeInput {
        string u, v;
        long long t;
    };
    vector<EdgeInput> temp_edges(edges_cnt);
    for(int i = 0; i < edges_cnt; ++i) {
        cin >> temp_edges[i].u >> temp_edges[i].v >> temp_edges[i].t;
        if(temp_edges[i].u != "S" && temp_edges[i].u != "T") {
            max_node_id = max(max_node_id, stoi(temp_edges[i].u));
        }
        if(temp_edges[i].v != "S" && temp_edges[i].v != "T") {
            max_node_id = max(max_node_id, stoi(temp_edges[i].v));
        }
    }

    // Arrays für O(1) Zugriff vorbereiten
    int n = max_node_id + 2;
    vector<string> node_names(n, "");
    node_names[0] = "S";
    node_names[n - 1] = "T";
    for(int i = 1; i <= max_node_id; ++i) {
        node_names[i] = to_string(i);
    }

    auto get_id = [&](const string &s) -> int {
        if (s == "S") return 0;
        if (s == "T") return n - 1;
        return stoi(s);
    };

    int S_id = get_id("S"); // Start
    int T_id = get_id("T"); // Ziel

    // Welches Werk gehört zu welchem Schritt?
    vector<vector<int>> works(m + 1);
    for(int i = 0; i < w; ++i) {
        int id = get_id(temp_works[i].first);
        works[temp_works[i].second].push_back(id);
    }

    int N = node_names.size();
    struct Edge {
        int to;
        long long weight;
    };
    vector<vector<Edge>> adj(N);

    // Ungerichteten Graphen aus den zwischengespeicherten Kanten aufbauen
    for(int i = 0; i < edges_cnt; ++i) {
        int u = get_id(temp_edges[i].u);
        int v = get_id(temp_edges[i].v);
        long long weight = temp_edges[i].t;
        adj[u].push_back({v, weight});
        adj[v].push_back({u, weight});
    }

    // 1. Dijkstra für alle Paare (Distanzen berechnen)
    vector<vector<long long>> dist_to(N, vector<long long>(N, INF));
    for(int dst = 0; dst < N; ++dst) {
        dist_to[dst][dst] = 0;
        priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<>> pq;
        pq.push({0, dst});

        while(!pq.empty()) {
            auto [d, u] = pq.top();
            pq.pop();

            if (d > dist_to[dst][u]) continue;

            for(auto &edge : adj[u]) {
                int v = edge.to;
                long long weight = edge.weight;
                if(dist_to[dst][u] + weight < dist_to[dst][v]) {
                    dist_to[dst][v] = dist_to[dst][u] + weight;
                    pq.push({dist_to[dst][v], v});
                }
            }
        }
    }

    auto dist_uv = [&](int u, int v) {
        return dist_to[v][u];
    };

    vector<vector<int>> next_node(N, vector<int>(N, -1));
    for(int u = 0; u < N; ++u) {
        for(int dst = 0; dst < N; ++dst) {
            if(u == dst || dist_to[dst][u] == INF) continue;
            for(auto &edge : adj[u]) {
                int v = edge.to;
                long long weight = edge.weight;
                if(dist_to[dst][v] != INF && weight + dist_to[dst][v] == dist_to[dst][u]) {
                    // Numerisches Tie-Breaking
                    if(next_node[u][dst] == -1 || v < next_node[u][dst]) {
                        next_node[u][dst] = v;
                    }
                }
            }
        }
    }

    // 2. Top-Down DP (Min-Max für beliebige Anzahl an Streiks)
    map<tuple<int, int, int, int>, long long> memo;
    map<tuple<int, int, int, int>, int> best_action;

    auto get_worst_case = [&](auto& self, int x, int k, int mask, int s) -> long long {
        // REIHENFOLGE GEFIXT: Zuerst prüfen, ob wir schon im Ziel sind!
        if (k > m) return dist_uv(x, T_id); // Alle Schritte abgeschlossen -> fahre ins Ziel
        if (mask == 0) return INF; // Alle wählbaren Werke sind bestreikt (und wir sind noch nicht fertig)

        auto state = make_tuple(x, k, mask, s);
        if (memo.count(state)) return memo[state];

        long long best_val = INF;
        int best_u = -1;

        for (int i = 0; i < works[k].size(); ++i) {
            if ((mask & (1 << i)) == 0) continue; // Werk bereits bestreikt
            int u = works[k][i];

            if (dist_uv(x, u) == INF) continue;

            // Fall 1: Werk u ist offen -> Nächster Schritt
            int next_mask = (k + 1 <= m) ? ((1 << works[k + 1].size()) - 1) : 0;
            long long cost_open = self(self, u, k + 1, next_mask, s);

            // Fall 2: Werk u wird bestreikt -> Bleibe im selben Schritt, reduziere Alternativen
            long long cost_closed = INF;
            bool can_strike = (s > 0) && ((mask ^ (1 << i)) != 0); // Gegner darf letztes Werk nicht bestreiken!

            if (can_strike) {
                cost_closed = self(self, u, k, mask ^ (1 << i), s - 1);
            }

            long long worst_case_for_u = INF;
            if (!can_strike) {
                if (cost_open != INF) {
                    worst_case_for_u = dist_uv(x, u) + cost_open;
                }
            } else {
                if (cost_open != INF && cost_closed != INF) {
                    worst_case_for_u = dist_uv(x, u) + max(cost_open, cost_closed);
                }
            }

            if (worst_case_for_u < best_val) {
                best_val = worst_case_for_u;
                best_u = i;
            } else if (worst_case_for_u == best_val && worst_case_for_u != INF) {
                // Numerisches Tie-Breaking
                if (best_u == -1 || u < works[k][best_u]) {
                    best_u = i;
                }
            }
        }

        best_action[state] = best_u;
        return memo[state] = best_val;
    };

    int initial_mask = (1 << works[1].size()) - 1;
    long long worst_case_total = get_worst_case(get_worst_case, S_id, 1, initial_mask, max_strikes);

    // 3. Zielprüfung und Rekonstruktion der Hauptroute
    if(worst_case_total > L || worst_case_total == INF) {
        cout << "UNMOEGLICH\n";
        return;
    }

    cout << "MOEGLICH\n";
    cout << worst_case_total << "\n\n";

    vector<int> W(m + 1);
    int curr_x = S_id;
    int curr_k = 1;
    int curr_mask = initial_mask;
    int curr_s = max_strikes;

    while (curr_k <= m) {
        auto state = make_tuple(curr_x, curr_k, curr_mask, curr_s);
        int best_i = best_action[state];
        int u = works[curr_k][best_i];

        W[curr_k] = u;
        curr_x = u;
        curr_k++;
        curr_mask = (curr_k <= m) ? ((1 << works[curr_k].size()) - 1) : 0;
    }

    vector<long long> arr(m + 1);
    arr[1] = dist_uv(S_id, W[1]);
    for(int k = 2; k <= m; ++k) {
        arr[k] = arr[k-1] + dist_uv(W[k-1], W[k]);
    }

    long long min_total = arr[m] + dist_uv(W[m], T_id);

    auto print_path = [&](int u, int v, int step_for_v) {
        int curr = u;
        while (curr != v) {
            curr = next_node[curr][v];
            if (curr == v) {
                if (step_for_v != -1) {
                    cout << " [" << node_names[v] << " " << step_for_v << "]";
                } else {
                    cout << " " << node_names[v];
                }
            } else {
                cout << " " << node_names[curr];
            }
        }
    };

    cout << min_total << "\n";
    cout << "S";
    int curr = S_id;
    for (int k = 1; k <= m; ++k) {
        print_path(curr, W[k], k);
        curr = W[k];
    }
    print_path(curr, T_id, -1);
    cout << "\n";

    // Fallbacks bewerten (Was passiert, wenn ein Werk der Hauptroute streikt?)
    if (max_strikes > 0) {
        for (int k = 1; k <= m; ++k) {
            int i_strike = -1;
            for(int i = 0; i < works[k].size(); ++i) {
                if(works[k][i] == W[k]) i_strike = i;
            }

            int f_mask = ((1 << works[k].size()) - 1) ^ (1 << i_strike);

            // Wenn nach dem Streik kein Werk mehr übrig wäre, durfte hier gar nicht gestreikt werden!
            if (f_mask == 0) continue;

            int f_s = max_strikes - 1;
            int f_x = W[k];
            int f_k = k;

            long long fallback_rest = get_worst_case(get_worst_case, f_x, f_k, f_mask, f_s);
            long long alt_duration = arr[k] + fallback_rest;

            cout << alt_duration << "\n";
            cout << node_names[W[k]];
            curr = W[k];

            while (f_k <= m) {
                auto state = make_tuple(f_x, f_k, f_mask, f_s);
                if(best_action.find(state) == best_action.end()) {
                    break;
                }
                int best_i = best_action[state];
                int v = works[f_k][best_i];

                print_path(curr, v, f_k);
                curr = v;
                f_x = v;
                f_k++;
                f_mask = (f_k <= m) ? ((1 << works[f_k].size()) - 1) : 0;
            }

            print_path(curr, T_id, -1);
            cout << "\n";
        }
    }

    cout << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    string fileN = "00";
    cerr << "Welches Beispiel? ";
    cin >> fileN;

    int max_strikes = 1;
    cerr << "Wie viele Werke streiken maximal? ";
    cin >> max_strikes;

    string in_dir = "inputs/" + fileN + ".txt";
    string out_dir = "outputs/" + fileN + "_" + to_string(max_strikes) + "_Streiks_out.txt";

    freopen(in_dir.c_str(), "r", stdin);

    freopen(out_dir.c_str(), "w", stdout);

    auto t0 = chrono::high_resolution_clock::now();
    solve(max_strikes);
    auto t1 = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = t1 - t0;

    cerr << elapsed.count() << "s\n";

    return 0;
}
